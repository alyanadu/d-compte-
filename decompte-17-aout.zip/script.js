
const countdownEl = document.getElementById("countdown");
const calendarEl = document.getElementById("calendar");

const startDate = new Date();
const endDate = new Date("2025-08-17");

function updateCountdown() {
  const now = new Date();
  const diff = endDate - now;
  const days = Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
  countdownEl.textContent = `Il reste ${days} jour(s) avant le 17 août.`;
}

function generateCalendar() {
  calendarEl.innerHTML = "";
  const today = new Date();
  let current = new Date(today);

  while (current <= endDate) {
    const dateStr = current.toISOString().split("T")[0];
    const label = document.createElement("label");
    label.style.display = "inline-block";
    label.style.margin = "5px";
    label.style.padding = "10px";
    label.style.border = "1px solid #e48abf";
    label.style.borderRadius = "8px";
    label.style.background = "#fdeef4";
    label.style.cursor = "pointer";

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.dataset.date = dateStr;
    checkbox.checked = localStorage.getItem(dateStr) === "true";
    checkbox.onchange = () => {
      localStorage.setItem(dateStr, checkbox.checked);
    };

    const day = document.createElement("div");
    day.textContent = current.toLocaleDateString("fr-FR", { weekday: "short", day: "numeric", month: "short" });

    label.appendChild(checkbox);
    label.appendChild(document.createElement("br"));
    label.appendChild(day);
    calendarEl.appendChild(label);

    current.setDate(current.getDate() + 1);
  }
}

updateCountdown();
generateCalendar();
